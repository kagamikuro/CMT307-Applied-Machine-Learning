Object Detection of people and body parts for VOC2012 dataset


Overview:

This program was created in order to locate and classify people, hands, heads and feet.
The dataset used, is a created subset of the VOC2012 dataset. The program is split into two parts:
	1. Analysis of the objects and images in the dataset
	2. Implementation and evaluation of a Mask R-CNN model using an implementation of 
		Mask R-CNN by Matterport.


Prerequisites:

This notebook was created and tested using google colab.

The enviroment uses tensorflow version 1.15 and keras version 2.2.5. If running this on a local enviroment
 please ensure that the versions of tensorflow and keras are 1.x and 2.2.5.

The code is also intended to be run using a GPU, if using google colab this can be selected by the following steps:
	.Select Runtime at the top.
	.Select Change runtime type.
	.Select Hardware accelerator.
	.From the drop down select GPU.



Running the Program:

The program below will complete the following steps in order.
	
	Unzip tar file and create dataset.
	Create csv file containing image annotations.
	Show descriptive analysis of the dataset results.
	Download mask_rcnn_coco weights and matterport Mask R-CNN.
	Create Train and test sets.
	Display sample train images.
	Define Configuration and train Mask R-CNN model.
	Calculate Mean Average Precision of the model.
	Output visulal predictions of test set images.


Acknowledgements:

Implementation was done using Mask R-CNN for Object Detection and Segmentation by matterport. 
The repository for Matterport's Mask R-CNN was taken from https://github.com/matterport/Mask_RCNN .
For more documentation on this please visit, https://github.com/matterport/Mask_RCNN .


The code to extract the image annotations from the annotation file was a modified version of the code found at:
 
https://github.com/qdraw/tensorflow-face-object-detector-tutorial/blob/master/003_xml-to-csv.py


To build and train the Mask-RCNN object detector we modified the code given in the tutorial, 
How to Train an Object Detection Model with Keras by Jason Brownlee. The link is found below:

https://machinelearningmastery.com/how-to-train-an-object-detection-model-with-keras/



